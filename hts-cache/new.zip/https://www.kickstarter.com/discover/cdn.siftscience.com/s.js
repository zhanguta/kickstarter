<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      href="https://ksr-static.imgix.net/static-favicon.png?ixlib=rb-2.0.0&auto=compress%2Cformat&s=91f5c2e7d615f798f4c91bc8d694ca9c"
      rel="icon"
      type="image/png"
    />
    <title>The page you were looking for doesn't exist (404)</title>
    <style type="text/css">
      body {
        margin: 0 auto 0 auto;
        background-color: #fff;
        color: #282828;
        font-family: 'Maison Neue Book', 'Helvetica Neue', arial, sans-serif;
      }
      .box {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        position: relative;
        -webkit-box-pack: center;
        -ms-flex-pack: center;
        justify-content: center;
        padding: 12px;
      }
      .content {
        margin: 12px;
      }
      .image {
        -webkit-box-flex: 0;
        -ms-flex: 0 0 18rem;
        flex: 0 0 18rem;
        -ms-flex-item-align: start;
        align-self: flex-start;
        position: relative;
      }
      .mobile-img {
        margin: 12px 4px 12px 4px;
      }

      h1 {
        font-size: 300%;
        line-height: 1em;
        margin: 0;
        padding: 0;
        font-weight: 400;
        margin-bottom: 0.1em;
        display: block;
      }
      p {
        color: #282828;
        line-height: 1.5;
        font-size: 90%;
        margin-bottom: 18px;
        margin-top: 0;
      }
      a {
        color: #282828;
      }
      a:hover {
        color: #037362;
      }
      .logo {
        display: block;
        border: 0;
        width: 190px;
        height: auto;
      }
      body {
        padding: 4px;
      }
      a.bttn {
        text-decoration: none;
      }
      .bttn {
        font-weight: 400;
        -webkit-transition: all 0.25s ease-in-out !important;
        -o-transition: all 0.25s ease-in-out !important;
        transition: all 0.25s ease-in-out !important;
        text-align: center;
        line-height: 1;
        cursor: pointer;
        background-color: #fff;
        border: none;
        position: relative;
        display: inline-block;
        -webkit-appearance: none;
        border-radius: 0;
      }
      .bttn:hover:not(:disabled) {
        transform: translateY(-1px);
      }
      .bttn.disabled:hover {
        transform: translateY(0);
      }
      .bttn::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        z-index: -1;
        width: 100%;
        height: 100%;
        opacity: 0;
        -webkit-box-shadow: 0 2px 4px rgba(40, 40, 40, 0.17);
        box-shadow: 0 2px 4px rgba(40, 40, 40, 0.17);
        -webkit-transition: all 0.25s ease-in-out !important;
        -o-transition: all 0.25s ease-in-out !important;
        transition: all 0.25s ease-in-out !important;
      }
      .bttn:hover:enabled:not(:active)::after {
        opacity: 1;
      }
      .bttn-medium {
        height: 42px;
        line-height: 42px;
        padding: 0 18px;
        font-size: 14px;
      }
      .bttn-white {
        -webkit-box-shadow: inset 0px 0px 0px 1px #dcdedd;
        box-shadow: inset 0px 0px 0px 1px #dcdedd;
        background-color: #ffffff;
        color: #282828 !important;
      }
      .bttn-white:hover:not(:disabled) {
        -webkit-box-shadow: inset 0px 0px 0px 1px #282828;
        box-shadow: inset 0px 0px 0px 1px #282828;
        background-color: #ffffff;
        color: #282828;
      }
      .bttn-black {
        background-color: #000000;
        color: #fff;
      }
      .bttn-black:active:enabled,
      .bttn-black:hover:enabled,
      .bttn-black:hover:not(:disabled) {
        background-color: #4d4d4d;
        color: #fff;
      }

      .rotate {
        display: none;
      }
      .wordmark {
        margin-bottom: 2rem;
      }

      #four {
        transform: rotate(-20deg);
        left: 16%;
        top: 16%;
      }
      #oh {
        transform: rotate(20deg);
        left: 40%;
        top: 40%;
      }
      #four2 {
        transform: rotate(-2deg);
        bottom: 15%;
        right: 15%;
      }
      #cube {
        transform: rotate(5deg);
        bottom: -8%;
        left: -16%;
      }
      #tube {
        transform: rotate(-5deg);
        top: -5%;
        right: -5%;
      }

      .wordmark {
        position: relative;
      }

      .message > p {
        margin-top: 20px;
      }

      @media screen and (min-width: 1006px) {
        p {
          font-size: 95%;
        }
        body {
          margin: 65px auto 0 auto;
        }
        .mobile-img {
          display: none;
        }
        .image {
          height: 640px;
          flex: 0 0 560px;
          overflow: hidden;
        }
        #bg-img {
          background: url('https://ksr-static.imgix.net/ksr10_blue_BG.jpg?ixlib=rb-1.1.0&fm=pjpg&s=d83389869a26498a0c411a4b97a8d8d9')
            repeat 0 0;
          position: relative;
          height: 100%;
        }
        .rotate {
          display: block;
          position: absolute;
        }

        .content {
          flex: 0 0 35%;
          display: flex;
          flex-direction: column;
          justify-content: center;
          position: relative;
        }
        .wordmark {
          position: absolute;
          top: 0;
          left: 0;
        }
        .message {
          align-self: center;
        }

        .message > p {
          padding-right: 100px;
        }
        .message > p.cta {
          font-size: 85%;
        }
        div.buttons {
          margin-top: 40px;
        }
      }
      @font-face {
        font-family: 'Maison Neue Book';
        font-display: swap;
        font-weight: 400;
        font-style: normal;
        src: url('https://d3mlfyygrfdi2i.cloudfront.net/maisonneue-book-webfont.eot')
            format('embedded-opentype'),
          url('https://d3mlfyygrfdi2i.cloudfront.net/maisonneue-book-webfont.woff2')
            format('woff2'),
          url('https://d3mlfyygrfdi2i.cloudfront.net/maisonneue-book-webfont.woff')
            format('woff');
      }
    </style>
  </head>

  <body>
    <div class="box">
      <div class="content">
        <a href="/" class="wordmark">
          <svg
            class="logo"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 598 70"
          >
            <title>Kickstarter</title>
            <g fill-rule="nonzero" style="fill: #282828;">
              <path
                d="M523,15.9 L523,47.3 C523,54.8 529.046512,61 536.403101,61 C542.449612,61 547.186047,57.3 548.899225,52 L550.310078,54.5 C552.829457,58.7 557.263566,61 561.79845,61 C569.155039,61 575,55.2 575,47.8 C575,45.3 574.395349,42.9 572.984496,40.7 L567.744186,32.4 C571.573643,29.5 573.891473,24.9 573.891473,19.3 C573.891473,9 565.627907,1 555.046512,1 L537.612403,1 C528.139535,1 523,6.1 523,15.9"
              ></path>
              <path
                d="M519,49.5030231 C519,43.7552636 515.323467,39.4192345 510.255814,38.4108557 C512.541226,36.8982874 513.932347,34.3773402 513.932347,31.04969 C513.932347,27.7220398 512.640592,25.2010926 510.255814,23.6885243 C515.422833,22.6801455 519,18.4449543 519,12.5963569 C519,6.14273218 513.832981,1 507.572939,1 L486.706131,1 C477.167019,1 472,6.14273218 472,15.9240071 L472,46.074535 C472,55.9566478 477.167019,60.9985421 486.706131,60.9985421 L507.572939,60.9985421 C513.832981,61.09938 519,55.9566478 519,49.5030231"
              ></path>
              <path
                d="M455.8,47.5 L455.8,26.8 C462.5,26.5 468,20.9 468,13.9 C468,6.7 462.2,1 455.1,1 L427.9,1 C420.8,1 415,6.6 415,13.9 C415,20.9 420.5,26.4 427.2,26.8 L427.2,47.5 C427.2,54.9 433.5,61 441.3,61 C449.6,61 455.8,54.9 455.8,47.5"
              ></path>
              <path
                d="M362,15.9 L362,47.3 C362,54.8 368.046512,61 375.403101,61 C381.449612,61 386.186047,57.3 387.899225,52 L389.310078,54.5 C391.829457,58.7 396.263566,61 400.79845,61 C408.155039,61 414,55.2 414,47.8 C414,45.3 413.395349,42.9 411.984496,40.7 L406.744186,32.4 C410.573643,29.5 412.891473,24.9 412.891473,19.3 C412.891473,9 404.627907,1 394.046512,1 L376.612403,1 C367.24031,1 362,6.1 362,15.9"
              ></path>
              <path
                d="M328.919678,49.5695364 C332.331325,56.6225166 337.147767,60 343.067976,60 C353.704285,60 361.229976,50.3642384 356.614219,39.5364238 L344.272087,10.9271523 C341.261811,3.87417219 336.746396,0 329.020021,0 C321.393988,0 316.878574,3.87417219 313.767955,10.9271523 L301.425823,39.5364238 C296.709724,50.3642384 304.335757,60 314.871723,60 C320.69159,60 325.508032,56.6225166 328.919678,49.5695364"
              ></path>
              <path
                d="M293.776938,47.5 L293.776938,26.8 C300.489603,26.5 306,20.9 306,13.9 C306,6.7 300.189036,1 293.075614,1 L265.924386,1 C258.810964,1 253,6.6 253,13.9 C253,20.9 258.510397,26.4 265.223062,26.8 L265.223062,47.5 C265.223062,54.9 271.534972,61 279.349716,61 C287.465028,61 293.776938,54.9 293.776938,47.5"
              ></path>
              <path
                d="M253,41.5361842 C253,35.5164474 249.993737,31.3026316 245.484342,27.2894737 L241.776618,23.9786184 C247.187891,23.1759868 250.795407,19.5641447 250.795407,14.2467105 C250.795407,5.31743421 243.680585,0 228.649269,0 C213.91858,0 205.300626,7.42434211 205.300626,19.1628289 C205.300626,25.1825658 208.407098,29.2960526 212.916493,33.4095395 L216.524008,36.7203947 L216.4238,36.7203947 C209.709812,36.7203947 205,40.6332237 205,46.7532895 C205,55.5822368 212.415449,61 228.248434,61 C243.780793,61 253,53.4753289 253,41.5361842"
                id="Shape-Copy-7"
              ></path>
              <path
                d="M202,46.5662429 C202,43.7802283 201.192523,41.0937143 199.476636,38.7057019 L193.016822,29.8501557 L199.476636,20.9946095 C201.192523,18.7060976 202,15.920083 202,13.1340685 C202,5.7710301 195.842991,0.0995005189 188.575701,0.0995005189 C184.336449,0.0995005189 180.097196,2.18901142 177.472897,5.7710301 L174.343925,10.1490529 C173.13271,4.27852231 167.985047,0 161.424299,0 C153.854206,0 148,5.97003114 148,13.3330695 L148,46.6657434 C148,54.0287818 153.95514,59.9988129 161.424299,59.9988129 C167.884112,59.9988129 172.930841,56.0187922 174.242991,50.2477621 L177.069159,54.2277828 C179.693458,58.0088025 184.033645,59.9988129 188.272897,59.9988129 C195.842991,60.0983134 202,53.9292813 202,46.5662429"
              ></path>
              <path
                d="M143,43.5099338 C143,37.1523179 139.818713,32.6821192 133.45614,30 C139.818713,27.3178808 143,22.9470199 143,16.4900662 C143,6.85430464 134.947368,0 122.023392,0 C104.725146,0 92,12.8145695 92,30 C92,47.1854305 104.725146,60 122.023392,60 C134.947368,60 143,53.1456954 143,43.5099338"
              ></path>
              <path
                d="M72.5499366,0 C64.4666385,0 58,6.57807309 58,14.3521595 L58,45.6478405 C58,53.5215947 64.4666385,60 72.4488953,60 C80.6332346,60 86.9988319,53.4219269 86.9988319,45.6478405 L86.9988319,14.3521595 C87.0998731,6.57807309 80.6332346,0 72.5499366,0"
              ></path>
              <path
                d="M54,46.5662429 C54,43.7802283 53.1940299,41.0937143 51.4813433,38.7057019 L45.0335821,29.8501557 L51.4813433,20.9946095 C53.1940299,18.7060976 54,15.920083 54,13.1340685 C54,5.7710301 47.8544776,0.0995005189 40.6007463,0.0995005189 C36.369403,0.0995005189 32.1380597,2.18901142 29.5186567,5.7710301 L26.2947761,10.1490529 C25.0858209,4.27852231 19.9477612,0 13.3992537,0 C5.84328358,0 0,5.97003114 0,13.3330695 L0,46.6657434 C0,54.0287818 5.94402985,59.9988129 13.3992537,59.9988129 C19.8470149,59.9988129 24.8843284,56.0187922 26.1940299,50.2477621 L29.0149254,54.2277828 C31.6343284,58.0088025 35.9664179,59.9988129 40.1977612,59.9988129 C47.8544776,60.0983134 54,53.9292813 54,46.5662429"
              ></path>
            </g>
          </svg>
        </a>
        <div class="mobile-img">
          <img
            src="https://ksr-static.imgix.net/Mobile_opt.png?ixlib=rb-1.1.0&fm=pjpg&s=f1304b333127d739c919a7f81bff55a2"
            width="100%"
            alt="404 Not Found"
          />
        </div>
        <div class="message">
          <h1>Back it up!</h1>
          <p>
            We can’t find this page, but we can show you a new creative project
            you can help bring to life.
          </p>
          <div class="buttons">
            <a
              href="/random-project?ref=404-ksr10"
              class="bttn bttn-medium bttn-black"
              >Take a chance</a
            >
            <a
              href="/?ref=404-ksr10"
              class="bttn bttn-medium bttn-white"
              alt="Country roads, take me home"
              >Take me home</a
            >
          </div>
          <p class="cta">
            <a href="http://status.kickstarter.com"
              >Check our status blog for updates</a
            >
          </p>
        </div>
      </div>
      <div class="image">
        <div id="bg-img">
          <img
            class="rotate"
            id="four"
            width="120"
            alt=""
            src="https://ksr-static.imgix.net/404_yellow-4.png?ixlib=rb-1.1.0&auto=compress&w=1000&fit=min&s=1343f12865108d53d8557040518a9175"
          />
          <img
            class="rotate"
            id="oh"
            width="120"
            alt=""
            src="https://ksr-static.imgix.net/404_yellow-03.png?ixlib=rb-1.1.0&auto=compress&w=1000&fit=min&s=bc5624a86dc9a1df3a938f15183d0769"
          />
          <img
            class="rotate"
            id="four2"
            width="120"
            alt=""
            src="https://ksr-static.imgix.net/404_yellow-4.png?ixlib=rb-1.1.0&auto=compress&w=1000&fit=min&s=1343f12865108d53d8557040518a9175"
          />
          <img
            class="rotate"
            id="cube"
            width="420"
            alt=""
            src="https://ksr-static.imgix.net/ksr10_blue_cube_404_500px.png?ixlib=rb-1.1.0&auto=compress&w=1000&fit=min&s=f8956b9dcb5930f12ce3abde67824eb4"
          />
          <img
            class="rotate"
            id="tube"
            width="300"
            alt=""
            src="https://ksr-static.imgix.net/ksr10_blue_tube_404_400px.png?ixlib=rb-1.1.0&auto=compress&w=1000&fit=min&s=a259a9c303556c83ce64ccf03dcdefb8"
          />
        </div>
      </div>
    </div>
    <script type="text/javascript">
      var background = document.getElementById('bg-img');
      var images = [].slice.call(document.getElementsByClassName('rotate'));
      // initial has to match the initial rotation of the elements in the CSS
      var config = {
        four: { degrees: 20, initial: -20, add: true },
        oh: { degrees: 25, initial: 20, add: false },
        four2: { degrees: 17, initial: -2, add: true },
        cube: { degrees: 22, initial: 5, add: false },
        tube: { degrees: 20, initial: -5, add: true }
      };
      function scale(num, in_min, in_max, out_min, out_max) {
        return (
          ((num - in_min) * (out_max - out_min)) / (in_max - in_min) + out_min
        );
      }
      function adjustImages(input) {
        var inMin = 0;
        var inMax = document.documentElement.clientWidth;

        if (input < inMax) {
          images.forEach(function(image) {
            var vectors = config[image.id];
            var transform = scale(input, inMin, inMax, 0, vectors.degrees);
            var newRotation = vectors.add
              ? vectors.initial + transform
              : vectors.initial - transform;
            image.style.transform = 'rotate(' + newRotation + 'deg)';
          });
          var backgroundRotation = scale(input, inMin, inMax, 0, 5);
          var newScale = scale(input, inMin, inMax, 1, 1.1);
          background.style.transform =
            'scale(' + newScale + ') rotate(' + backgroundRotation + 'deg)';
        }
      }
      window.addEventListener('mousemove', function(event) {
        adjustImages(event.clientX);
      });
    </script>
  </body>
</html>
